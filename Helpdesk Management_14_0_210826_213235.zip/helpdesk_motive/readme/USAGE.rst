* Go to Helpdesk
* Create a ticket and set its motive. The list of motives is limited by the team.
