This module adds a motive field on the helpdesk ticket.
The list is filtered based on the helpdesk team.
