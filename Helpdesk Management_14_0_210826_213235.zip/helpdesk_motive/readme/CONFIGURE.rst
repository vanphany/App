* Go to Helpdesk > Configuration > Motives
* Create your list of different motives with their name and teams
