This module adds a type field on the helpdesk ticket.
